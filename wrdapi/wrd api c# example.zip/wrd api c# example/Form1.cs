using System.Runtime.InteropServices;

namespace WeAreDevs_API
{
    public partial class Form1 : Form
    {
        [DllImport("kernel32.dll")]
        static extern bool AllocConsole();

        [DllImport("wearedevs_exploit_api.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern byte attach();

        [DllImport("wearedevs_exploit_api.dll", CallingConvention = CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool isAttached();

        [DllImport("wearedevs_exploit_api.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void execute([MarshalAs(UnmanagedType.LPStr)] string script);


        public Form1()
        {
            InitializeComponent();
            AllocConsole();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            string script = txtScript.Text;
            execute(script);
        }

        private void timerAttachChecker_Tick(object sender, EventArgs e)
        {
            bool attached = isAttached();
            if (attached)
            {
                labelStatus.Text = "Status: Attached";
                labelStatus.ForeColor = Color.Green;
            }
            else
            {
                labelStatus.Text = "Status: Not attached";
                labelStatus.ForeColor = Color.Red;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            attach();
        }
    }
}
