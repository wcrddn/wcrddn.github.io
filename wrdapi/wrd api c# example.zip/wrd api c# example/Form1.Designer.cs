﻿namespace WeAreDevs_API
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtScript = new RichTextBox();
            btnExecute = new Button();
            labelStatus = new Label();
            timerAttachChecker = new System.Windows.Forms.Timer(components);
            button1 = new Button();
            SuspendLayout();
            // 
            // txtScript
            // 
            txtScript.Location = new Point(10, 10);
            txtScript.Margin = new Padding(2, 2, 2, 2);
            txtScript.Name = "txtScript";
            txtScript.Size = new Size(803, 371);
            txtScript.TabIndex = 0;
            txtScript.Text = "print(\"Hello, World!\")";
            // 
            // btnExecute
            // 
            btnExecute.Location = new Point(611, 385);
            btnExecute.Margin = new Padding(2, 2, 2, 2);
            btnExecute.Name = "btnExecute";
            btnExecute.Size = new Size(90, 27);
            btnExecute.TabIndex = 1;
            btnExecute.Text = "Execute";
            btnExecute.UseVisualStyleBackColor = true;
            btnExecute.Click += btnExecute_Click;
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Location = new Point(10, 389);
            labelStatus.Margin = new Padding(2, 0, 2, 0);
            labelStatus.Name = "labelStatus";
            labelStatus.Size = new Size(80, 20);
            labelStatus.TabIndex = 2;
            labelStatus.Text = "Status: null";
            // 
            // timerAttachChecker
            // 
            timerAttachChecker.Enabled = true;
            timerAttachChecker.Tick += timerAttachChecker_Tick;
            // 
            // button1
            // 
            button1.Location = new Point(723, 386);
            button1.Margin = new Padding(2);
            button1.Name = "button1";
            button1.Size = new Size(90, 27);
            button1.TabIndex = 3;
            button1.Text = "Attach";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(825, 420);
            Controls.Add(button1);
            Controls.Add(labelStatus);
            Controls.Add(btnExecute);
            Controls.Add(txtScript);
            Margin = new Padding(2, 2, 2, 2);
            Name = "Form1";
            Text = "WeAreDevs API C# Demo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox txtScript;
        private Button btnExecute;
        private Button btnAttach;
        private Label labelStatus;
        private System.Windows.Forms.Timer timerAttachChecker;
        private Button button1;
    }
}
